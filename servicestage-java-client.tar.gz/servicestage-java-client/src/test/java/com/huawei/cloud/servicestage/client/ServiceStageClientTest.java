/**
 * Copyright 2016 - 2017 Huawei Technologies Co., Ltd. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.huawei.cloud.servicestage.client;

import static org.junit.Assert.*;

import java.io.IOException;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * @author Farhan Arshad (farhan.arshad@huawei.com)
 */
public class ServiceStageClientTest {

    private static Token token;

    /**
     * @throws java.lang.Exception
     */
    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        token = AuthHelper.getInstance().getToken();
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    /**
     * Test method for
     * {@link com.huawei.cloud.servicestage.client.ServiceStageClient#createService(java.lang.String, com.huawei.cloud.servicestage.client.ServiceInstanceRequestBody, com.huawei.cloud.servicestage.client.Token)}.
     */
    @Test
    public void testCreateServiceStringServiceInstanceRequestBodyToken() {
    }

    /**
     * Test method for
     * {@link com.huawei.cloud.servicestage.client.ServiceStageClient#createService(java.lang.String, java.lang.String, com.huawei.cloud.servicestage.client.Token)}.
     */
    @Test
    public void testCreateServiceStringStringToken() {
    }

    /**
     * Test method for
     * {@link com.huawei.cloud.servicestage.client.ServiceStageClient#getAppTShirtSizes(com.huawei.cloud.servicestage.client.Token)}.
     * 
     * @throws IOException
     */
    @Test
    public void testGetAppTShirtSizes() throws IOException {
        Map<String, String> sizes = ServiceStageClient.getAppTShirtSizes(token);

        assertNotNull(sizes);

        System.out.println(sizes);
    }

    /**
     * Test method for
     * {@link com.huawei.cloud.servicestage.client.ServiceStageClient#getApplicationTypes(com.huawei.cloud.servicestage.client.Token)}.
     * 
     * @throws IOException
     */
    @Test
    public void testGetApplicationTypes() throws IOException {
        Map<String, String> types = ServiceStageClient
                .getApplicationTypes(token);

        assertNotNull(types);

        System.out.println(types);
    }

    /**
     * Test method for
     * {@link com.huawei.cloud.servicestage.client.ServiceStageClient#getApplicationInfo(java.lang.String, com.huawei.cloud.servicestage.client.Token)}.
     * 
     * @throws IOException
     */
    @Test
    public void testGetApplicationInfo() throws IOException {
        SimpleResponse response = ServiceStageClient.getApplicationInfo(
                "8e9cf682-deab-4744-b782-ccdc38bd4df0", token);
        System.out.println(response.getMessage());

        assertTrue(response.isOk());
    }

    @Test
    public void testGetApplicationStatus() throws IOException {
        String response = ServiceStageClient.getApplicationStatus(
                "8e9cf682-deab-4744-b782-ccdc38bd4df0", token);

        assertNotNull("Status was null", response);

        System.out.println(response);
    }

    /**
     * Test method for
     * {@link com.huawei.cloud.servicestage.client.ServiceStageClient#getApplicationTaskLogs(java.lang.String, com.huawei.cloud.servicestage.client.Token)}.
     */
    @Test
    public void testGetApplicationTaskLogs() {
    }

}

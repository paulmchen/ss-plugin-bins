package com.huawei.cloud.cas.clients;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import com.huawei.cloud.servicestage.client.AuthClient;
import com.huawei.cloud.servicestage.client.Token;

public class AuthHelper {
    public static final String REGION = "cn-north-1";

    public static final String USERNAME = "";

    public static final String PASSWORD = "";

    public static final String TENANT_ID = "";

    private static AuthHelper instance = null;

    private Token token = null;

    protected AuthHelper() throws IOException {
        this.token = AuthClient.getAuthToken(REGION, USERNAME, PASSWORD);
        assertNotNull("Failed to get Auth Token.", this.token);
    }

    public static AuthHelper getInstance() throws IOException {
        if (instance == null) {
            instance = new AuthHelper();
        }

        return instance;
    }

    public Token getToken() {
        return this.token;
    }
}

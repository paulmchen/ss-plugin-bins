/**
 * Copyright 2016 - 2017 Huawei Technologies Co., Ltd. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.huawei.cloud.servicestage.eclipse;

/**
 * Locale specific text values
 * 
 * @author Farhan Arshad (farhan.arshad@huawei.com)
 */
public interface Resources {
    // Huawei Preferences Page
    static final String PREFERENCES_HUAWEI_DESCRIPTION = Activator
            .getResourceString("preferences.huawei.description");

    static final String PREFERENCES_HUAWEI_SELECT_REGION = Activator
            .getResourceString("preferences.huawei.selectRegion");

    static final String PREFERENCES_HUAWEI_REGION_CHOICE_1 = Activator
            .getResourceString("preferences.huawei.regionChoice1");

    static final String PREFERENCES_HUAWEI_REGION_CHOICE_2 = Activator
            .getResourceString("preferences.huawei.regionChoice2");

    static final String PREFERENCES_HUAWEI_REGION_CHOICE_3 = Activator
            .getResourceString("preferences.huawei.regionChoice3");

    static final String PREFERENCES_HUAWEI_REGION_CHOICE_4 = Activator
            .getResourceString("preferences.huawei.regionChoice4");

    static final String PREFERENCES_HUAWEI_REGION_CHOICE_5 = Activator
            .getResourceString("preferences.huawei.regionChoice5");

    static final String PREFERENCES_HUAWEI_USERNAME = Activator
            .getResourceString("preferences.huawei.username");

    static final String PREFERENCES_HUAWEI_PASSWORD = Activator
            .getResourceString("preferences.huawei.password");

    static final String PREFERENCES_HUAWEI_STORE_SECURELY = Activator
            .getResourceString("preferences.huawei.storeSecurely");

    static final String PREFERENCES_HUAWEI_SECURE_STORAGE_NOTE = Activator
            .getResourceString("preferences.huawei.secureStorageNote");

    static final String PREFERENCES_HUAWEI_RESET_TOKEN = Activator
            .getResourceString("preferences.huawei.resetToken");

    // Service Stage Preferences Page
    static final String PREFERENCES_SERVICESTAGE_DESCRIPTION = Activator
            .getResourceString("preferences.huawei.description");

    static final String PREFERENCES_SERVICESTAGE_ARTIFACT_NAMESPACE = Activator
            .getResourceString("preferences.huawei.artifactNamespace");

    static final String PREFERENCES_SERVICESTAGE_CAS_CLUSTER_NAMESPACE = Activator
            .getResourceString("preferences.huawei.casClusterNamespace");

    static final String PREFERENCES_SERVICESTAGE_SERVICE_ID = Activator
            .getResourceString("preferences.huawei.serviceId");

    static final String PREFERENCES_SERVICESTAGE_PLAN_ID = Activator
            .getResourceString("preferences.huawei.planId");

    static final String PREFERENCES_SERVICESTAGE_ORGANIZATION_GUID = Activator
            .getResourceString("preferences.huawei.organizationGuid");

    static final String PREFERENCES_SERVICESTAGE_SPACE_GUID = Activator
            .getResourceString("preferences.huawei.spaceGuid");

    static final String PREFERENCES_SERVICESTAGE_CONTEXT_ORDER_ID = Activator
            .getResourceString("preferences.huawei.contextOrderId");

    // App Wizard Page
    static final String WIZARD_APP_PAGE_PAGE_NAME = Activator
            .getResourceString("wizard.appPage.pageName");

    static final String WIZARD_APP_PAGE_TITLE = Activator
            .getResourceString("wizard.appPage.title");

    static final String WIZARD_APP_PAGE_DESCRIPTION = Activator
            .getResourceString("wizard.appPage.description");

    static final String WIZARD_APP_PAGE_SERVICE_INSTANCE_GROUP_NAME = Activator
            .getResourceString("wizard.appPage.serviceInstanceGroupName");

    static final String WIZARD_APP_PAGE_SERVICE_INSTANCE_ID = Activator
            .getResourceString("wizard.appPage.serviceInstanceId");

    static final String WIZARD_APP_PAGE_APPLICATION_GROUP_NAME = Activator
            .getResourceString("wizard.appPage.applicationGroupName");

    static final String WIZARD_APP_PAGE_APP_ID = Activator
            .getResourceString("wizard.appPage.appID");

    static final String WIZARD_APP_PAGE_APP_DISPLAY_NAME = Activator
            .getResourceString("wizard.appPage.appDisplayName");

    static final String WIZARD_APP_PAGE_APP_VERSION = Activator
            .getResourceString("wizard.appPage.appVersion");

    static final String WIZARD_APP_PAGE_APP_DESCRIPTION = Activator
            .getResourceString("wizard.appPage.appDescription");

    static final String WIZARD_APP_PAGE_APP_TYPE = Activator
            .getResourceString("wizard.appPage.appType");

    static final String WIZARD_APP_PAGE_APP_TYPE_ERROR = Activator
            .getResourceString("wizard.appPage.appTypeError");

    static final String WIZARD_APP_PAGE_PLATFORM_GROUP_NAME = Activator
            .getResourceString("wizard.appPage.platformGroupName");

    static final String WIZARD_APP_PAGE_APP_CLUSTER_ID = Activator
            .getResourceString("wizard.appPage.appClusterId");

    static final String WIZARD_APP_PAGE_APP_ELB_ID = Activator
            .getResourceString("wizard.appPage.appElbId");

    static final String WIZARD_APP_PAGE_APP_VPC_ID = Activator
            .getResourceString("wizard.appPage.appVpcId");

    static final String WIZARD_APP_PAGE_APP_SIZE = Activator
            .getResourceString("wizard.appPage.appSize");

    static final String WIZARD_APP_PAGE_APP_SIZE_ERROR = Activator
            .getResourceString("wizard.appPage.appSizeError");

    static final String WIZARD_APP_PAGE_APP_REPLICAS = Activator
            .getResourceString("wizard.appPage.appReplicas");

    static final String WIZARD_APP_PAGE_PORT = Activator
            .getResourceString("wizard.appPage.port");

    // Source Wizard Page
    static final String WIZARD_SRC_PAGE_PAGE_NAME = Activator
            .getResourceString("wizard.srcPage.pageName");

    static final String WIZARD_SRC_PAGE_TITLE = Activator
            .getResourceString("wizard.srcPage.title");

    static final String WIZARD_SRC_PAGE_DESCRIPTION = Activator
            .getResourceString("wizard.srcPage.description");

    static final String WIZARD_SRC_PAGE_SWR_GROUP_NAME = Activator
            .getResourceString("wizard.srcPage.swrGroupName");

    static final String WIZARD_SRC_PAGE_SWR_REPO = Activator
            .getResourceString("wizard.srcPage.swrRepo");

    static final String WIZARD_SRC_PAGE_SWR_PACKAGE = Activator
            .getResourceString("wizard.srcPage.swrPackage");

    static final String WIZARD_SRC_PAGE_SWR_VERSION = Activator
            .getResourceString("wizard.srcPage.swrVersion");

    static final String WIZARD_SRC_PAGE_SRC_GROUP_NAME = Activator
            .getResourceString("wizard.srcPage.srcGroupName");

    static final String WIZARD_SRC_PAGE_LOCAL_FILE = Activator
            .getResourceString("wizard.srcPage.localFile");

    static final String WIZARD_SRC_PAGE_DEVCLOUD = Activator
            .getResourceString("wizard.srcPage.devcloud");

    static final String WIZARD_SRC_PAGE_GITHUB = Activator
            .getResourceString("wizard.srcPage.github");

    static final String WIZARD_SRC_PAGE_GITEE = Activator
            .getResourceString("wizard.srcPage.gitee");

    static final String WIZARD_SRC_PAGE_BITBUCKET = Activator
            .getResourceString("wizard.srcPage.bitbucket");

    static final String WIZARD_SRC_PAGE_GITLAB = Activator
            .getResourceString("wizard.srcPage.gitlab");

    static final String WIZARD_SRC_PAGE_SELECT_SOURCE = Activator
            .getResourceString("wizard.srcPage.selectSource");

    static final String WIZARD_SRC_PAGE_PATH = Activator
            .getResourceString("wizard.srcPage.path");

    static final String WIZARD_SRC_PAGE_NAMESPACE = Activator
            .getResourceString("wizard.srcPage.namespace");

    static final String WIZARD_SRC_PAGE_BRANCH = Activator
            .getResourceString("wizard.srcPage.branch");

    static final String WIZARD_SRC_PAGE_SECU_TOKEN = Activator
            .getResourceString("wizard.srcPage.secuToken");

    // Services Wizard Page
    static final String WIZARD_SERVICES_PAGE_PAGE_NAME = Activator
            .getResourceString("wizard.servicesPage.pageName");

    static final String WIZARD_SERVICES_PAGE_TITLE = Activator
            .getResourceString("wizard.servicesPage.title");

    static final String WIZARD_SERVICES_PAGE_DESCRIPTION = Activator
            .getResourceString("wizard.servicesPage.description");

    static final String WIZARD_SERVICES_PAGE_DCS_GROUP_NAME = Activator
            .getResourceString("wizard.servicesPage.dcsGroupName");

    static final String WIZARD_SERVICES_PAGE_DCS_ID = Activator
            .getResourceString("wizard.servicesPage.dcsId");

    static final String WIZARD_SERVICES_PAGE_DCS_DESCRIPTION = Activator
            .getResourceString("wizard.servicesPage.dcsDescription");

    static final String WIZARD_SERVICES_PAGE_DCS_CLUSTER = Activator
            .getResourceString("wizard.servicesPage.dcsCluster");

    static final String WIZARD_SERVICES_PAGE_DCS_PASSWORD = Activator
            .getResourceString("wizard.servicesPage.dcsPassword");

    static final String WIZARD_SERVICES_PAGE_DCS_VERSION = Activator
            .getResourceString("wizard.servicesPage.dcsVersion");

    static final String WIZARD_SERVICES_PAGE_DCS_TYPE = Activator
            .getResourceString("wizard.servicesPage.dcsType");

    static final String WIZARD_SERVICES_PAGE_RDS_GROUP_NAME = Activator
            .getResourceString("wizard.servicesPage.rdsGroupName");

    static final String WIZARD_SERVICES_PAGE_RDS_ID = Activator
            .getResourceString("wizard.servicesPage.rdsId");

    static final String WIZARD_SERVICES_PAGE_RDS_DESCRIPTION = Activator
            .getResourceString("wizard.servicesPage.rdDescription");

    static final String WIZARD_SERVICES_PAGE_RDS_CONNECTION_TYPE = Activator
            .getResourceString("wizard.servicesPage.rdsConnectionType");

    static final String WIZARD_SERVICES_PAGE_RDS_DB_NAME = Activator
            .getResourceString("wizard.servicesPage.rdsDbName");

    static final String WIZARD_SERVICES_PAGE_RDS_DB_USER = Activator
            .getResourceString("wizard.servicesPage.rdsDbUser");

    static final String WIZARD_SERVICES_PAGE_RDS_DB_PASSWORD = Activator
            .getResourceString("wizard.servicesPage.rdsDbPassword");

    // Dialogs
    static final String DIALOG_NO_RESOURCE_SELECTED_TITLE = Activator
            .getResourceString("dialog.noResourceSelectedTitle");

    static final String DIALOG_NO_RESOURCE_SELECTED_MESSAGE = Activator
            .getResourceString("dialog.noResourceSelectedMessage");

    static final String DIALOG_NO_FILE_SELECTED_MESSAGE = Activator
            .getResourceString("dialog.noFileSelectedMessage");

    static final String DIALOG_DEPLOY_TITLE = Activator
            .getResourceString("dialog.deploy.title");

    static final String DIALOG_DEPLOY_MESSAGE = Activator
            .getResourceString("dialog.deploy.message");

    static final String DIALOG_STATUS_ERROR = Activator
            .getResourceString("dialog.status.error");

    static final String DIALOG_STATUS_MESSAGE = Activator
            .getResourceString("dialog.status.message");

    static final String DIALOG_STATUS_URLMESSAGE = Activator
            .getResourceString("dialog.status.urlMessage");

    // Jobs
    static final String JOB_DEPLOY_NAME = Activator
            .getResourceString("job.deploy.name");

    static final String JOB_DEPLOY_UPLOAD = Activator
            .getResourceString("job.deploy.upload");

    static final String JOB_DEPLOY_UPLOAD_FAILED = Activator
            .getResourceString("job.deploy.upload.failed");

    static final String JOB_DEPLOY_DEPLOY = Activator
            .getResourceString("job.deploy.deploy");

    static final String JOB_DEPLOY_DEPLOY_FAILED = Activator
            .getResourceString("job.deploy.deploy.failed");

    static final String JOB_DEPLOY_MONITOR_TIMEOUT = Activator
            .getResourceString("job.deploy.monitor.timeout");

    static final String JOB_DEPLOY_MONITOR_ERROR = Activator
            .getResourceString("job.deploy.monitor.error");

    static final String JOB_DEPLOY_URL = Activator
            .getResourceString("job.deploy.url");

    static final String JOB_DEPLOY_URL_FAILED = Activator
            .getResourceString("job.deploy.url.failed");

    static final String JOB_DEPLOY_SUCCESSFUL = Activator
            .getResourceString("job.deploy.successful");

    // General
    static final String INFO = Activator.getResourceString("info");

    static final String ERROR = Activator.getResourceString("error");

    static final String SUCCESSFUL = Activator.getResourceString("successful");

    static final String FAILED = Activator.getResourceString("failed");

    static final String SEE_DETAILS = Activator.getResourceString("seeDetails");

}
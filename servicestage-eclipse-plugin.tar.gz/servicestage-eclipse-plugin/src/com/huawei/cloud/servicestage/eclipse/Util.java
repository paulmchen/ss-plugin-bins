/**
 * Copyright 2016 - 2017 Huawei Technologies Co., Ltd. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.huawei.cloud.servicestage.eclipse;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.dialogs.DialogSettings;
import org.eclipse.jface.dialogs.ErrorDialog;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;

/**
 * @author Farhan Arshad (farhan.arshad@huawei.com)
 */
public class Util implements Resources {
    public static IDialogSettings loadDialogSettings(IProject project)
            throws IOException {
        File settingsFile = getSettingsFile(project);

        if (settingsFile == null || !settingsFile.exists()) {
            return new DialogSettings("Service Stage Settings");
        }

        DialogSettings settings = new DialogSettings("Service Stage Settings");
        project.getWorkspace().toString();
        settings.load(settingsFile.getAbsolutePath());
        return settings;
    }

    public static File getSettingsFile(IProject project) {
        IFile settingsFile = project
                .getFile(ConfigConstants.DIALOG_SETTINGS_FILE_NAME);

        return new File(
                settingsFile.getRawLocation().makeAbsolute().toString());
    }

    public static void refreshSettingsFile(IProject project) {
        IFile settingsFile = project
                .getFile(ConfigConstants.DIALOG_SETTINGS_FILE_NAME);

        try {
            project.refreshLocal(IResource.DEPTH_ONE, null);
            settingsFile.refreshLocal(IResource.DEPTH_ZERO, null);
        } catch (CoreException e) {
            e.printStackTrace();
        }
    }

    public static void saveDialogSettings(IProject project,
            IDialogSettings settings) throws IOException {
        File settingsFile = getSettingsFile(project);

        settings.save(settingsFile.getAbsolutePath());
        refreshSettingsFile(project);
    }

    public static URL getPluginFileUrl(String path) {
        return Activator.getDefault().getBundle().getEntry(path);
    }

    public static String exceptionToString(Exception e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);

        e.printStackTrace(pw);

        return sw.toString();
    }

    public static void showInfoDialog(String title, String message,
            Shell shell) {
        MessageDialog.openInformation(shell, title, message);
        Logger.info(title, message);
    }

    public static void showInfoDialog(String title, String message,
            String details, Shell shell) {
        MultiStatus info = new MultiStatus(Activator.PLUGIN_ID, IStatus.INFO,
                SEE_DETAILS, null);
        info.add(new Status(IStatus.INFO, Activator.PLUGIN_ID, details, null));
        ErrorDialog.openError(shell, title, message, info);
        Logger.info(title, message, details);
    }

    public static void showExceptionDialog(String message, Shell shell,
            Exception e) {
        showExceptionDialog(ERROR, message, shell, e);
    }

    public static void showExceptionDialog(String title, String message,
            Shell shell, Exception e) {
        MultiStatus error = new MultiStatus(Activator.PLUGIN_ID, IStatus.ERROR,
                SEE_DETAILS, null);
        error.add(new Status(IStatus.ERROR, Activator.PLUGIN_ID,
                Util.exceptionToString(e), null));
        ErrorDialog.openError(shell, title, message, error);
        Logger.exception(title, e);
    }

    public static void showJobInfoDialog(String title, String message,
            Shell shell) {
        Action action = new Action() {
            public void run() {
                Util.showInfoDialog(title, message, shell);
            }
        };

        Display.getDefault().asyncExec(() -> {
            action.run();
        });
    }

    public static void showJobInfoDialog(String title, String message,
            String details, Shell shell) {
        Action action = new Action() {
            public void run() {
                Util.showInfoDialog(title, message, details, shell);
            }
        };

        Display.getDefault().asyncExec(() -> {
            action.run();
        });
    }

    public static void showJobExceptionDialog(String message, Shell shell,
            Exception e) {
        showJobExceptionDialog(ERROR, message, shell, e);
    }

    public static void showJobExceptionDialog(String title, String message,
            Shell shell, Exception e) {
        Action action = new Action() {
            public void run() {
                Util.showExceptionDialog(title, message, shell, e);
            }
        };

        Display.getDefault().asyncExec(() -> {
            action.run();
        });
    }

}

/**
 * Copyright 2016 - 2017 Huawei Technologies Co., Ltd. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.huawei.cloud.servicestage.eclipse;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.eclipse.equinox.security.storage.StorageException;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;

/**
 * @author Farhan Arshad (farhan.arshad@huawei.com)
 */
public class SourceConfigWizardPage extends AbstractConfigWizardPage
        implements Resources {

    // displayValue -> apiValue
    private static final Map<String, String> sourceTypes = new LinkedHashMap<>();

    static {
        sourceTypes.put(WIZARD_SRC_PAGE_LOCAL_FILE,
                ConfigConstants.SOURCE_TYPE_LOCAL_FILE);
        sourceTypes.put(WIZARD_SRC_PAGE_DEVCLOUD,
                ConfigConstants.SOURCE_TYPE_DEVCLOUD);
        sourceTypes.put(WIZARD_SRC_PAGE_GITHUB,
                ConfigConstants.SOURCE_TYPE_GITHUB);
        sourceTypes.put(WIZARD_SRC_PAGE_GITEE,
                ConfigConstants.SOURCE_TYPE_GITEE);
        sourceTypes.put(WIZARD_SRC_PAGE_BITBUCKET,
                ConfigConstants.SOURCE_TYPE_BITBUCKET);
        sourceTypes.put(WIZARD_SRC_PAGE_GITLAB,
                ConfigConstants.SOURCE_TYPE_GITLAB);
    }

    public SourceConfigWizardPage() {
        super(WIZARD_SRC_PAGE_PAGE_NAME);
        setTitle(WIZARD_SRC_PAGE_TITLE);
        setDescription(WIZARD_SRC_PAGE_DESCRIPTION);
    }

    @Override
    public void createControl(Composite parent) {
        // outer container
        Composite container = createContainer(parent);

        // swr upload info group
        Group localGroup = createGroup(container,
                WIZARD_SRC_PAGE_SWR_GROUP_NAME);

        // only local file is currently supported
        getDialogSettings().put(ConfigConstants.SOURCE_TYPE_OPTION,
                new String[] { WIZARD_SRC_PAGE_LOCAL_FILE,
                        ConfigConstants.SOURCE_TYPE_LOCAL_FILE });

        Combo repoCombo = addDropdown(ConfigConstants.SWR_REPO,
                WIZARD_SRC_PAGE_SWR_REPO, getRepos(), localGroup);

        Combo packagesCombo = addDropdown(ConfigConstants.SWR_PACKAGE,
                WIZARD_SRC_PAGE_SWR_PACKAGE, getPackages(repoCombo.getText()),
                localGroup);

        repoCombo.addModifyListener(event -> {
            this.setErrorMessage(null);
            packagesCombo.removeAll();

            for (String pkg : getPackages(repoCombo.getText())) {
                packagesCombo.add(pkg);
            }
        });

        Combo versionsCombo = addDropdown(ConfigConstants.SWR_VERSION,
                WIZARD_SRC_PAGE_SWR_VERSION,
                getVersions(repoCombo.getText(), packagesCombo.getText()),
                localGroup);

        packagesCombo.addModifyListener(event -> {
            this.setErrorMessage(null);
            versionsCombo.removeAll();

            for (String version : getVersions(repoCombo.getText(),
                    packagesCombo.getText())) {
                versionsCombo.add(version);
            }
        });

        // git is currently not supported
        // // source group
        // Group srcGroup = createGroup(container,
        // WIZARD_SRC_PAGE_SRC_GROUP_NAME);
        // Combo combo = addDropdown(ConfigConstants.SOURCE_TYPE_OPTION,
        // WIZARD_SRC_PAGE_SELECT_SOURCE, sourceTypes, srcGroup);
        // // addField(PluginConstants.SOURCE_PATH, WIZARD_SRC_PAGE_PATH,
        // // srcGroup);
        //
        // Text namespaceField = addField(ConfigConstants.SOURCE_NAMESPACE,
        // WIZARD_SRC_PAGE_NAMESPACE, srcGroup);
        // Text branchField = addField(ConfigConstants.SOURCE_BRANCH,
        // WIZARD_SRC_PAGE_BRANCH, srcGroup);
        // Text secuTokenField = addField(ConfigConstants.SOURCE_SECU_TOKEN,
        // WIZARD_SRC_PAGE_SECU_TOKEN, srcGroup);
        //
        // // disable fields that are not required for local
        // // special case for initial value
        // if (combo.getText().equals(WIZARD_SRC_PAGE_LOCAL_FILE)) {
        // namespaceField.setEnabled(false);
        // branchField.setEnabled(false);
        // secuTokenField.setEnabled(false);
        // }
        //
        // // add listener to disable/enable when needed
        // combo.addModifyListener(e -> {
        // String displayValue = combo.getText();
        //
        // if (displayValue.equals(WIZARD_SRC_PAGE_LOCAL_FILE)) {
        // namespaceField.setEnabled(false);
        // branchField.setEnabled(false);
        // secuTokenField.setEnabled(false);
        // } else {
        // namespaceField.setEnabled(true);
        // branchField.setEnabled(true);
        // secuTokenField.setEnabled(true);
        // }
        // });
    }

    @Override
    protected int getPageLabelWidth() {
        return 100;
    }

    private Set<String> getRepos() {
        Set<String> repos = Collections.emptySet();
        try {
            repos = RequestManager.getInstance().getRepos();
        } catch (IOException | StorageException e) {
            Logger.exception(e);
            this.setErrorMessage(e.getMessage());
        }

        return repos;
    }

    private Set<String> getPackages(String repo) {
        Set<String> packages = Collections.emptySet();

        if (repo != null && !repo.isEmpty()) {
            try {
                packages = RequestManager.getInstance().getPackages(repo);
            } catch (IOException | StorageException e) {
                Logger.exception(e);
                this.setErrorMessage(e.getMessage());
            }
        }

        return packages;
    }

    private Set<String> getVersions(String repo, String pkg) {
        Set<String> versions = Collections.emptySet();

        if (repo != null && !repo.isEmpty() && pkg != null && !pkg.isEmpty()) {
            try {
                versions = RequestManager.getInstance().getVersions(repo, pkg);
            } catch (IOException | StorageException e) {
                Logger.exception(e);
                this.setErrorMessage(e.getMessage());
            }
        }
        return versions;
    }

}

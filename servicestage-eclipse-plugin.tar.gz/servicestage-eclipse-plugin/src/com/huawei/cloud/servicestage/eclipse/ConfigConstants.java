/**
 * Copyright 2016 - 2017 Huawei Technologies Co., Ltd. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.huawei.cloud.servicestage.eclipse;

/**
 * Constants for the settings file
 * 
 * @author Farhan Arshad (farhan.arshad@huawei.com)
 */
public class ConfigConstants {
    public static final String SERVICE_INSTANCE_ID = "Service Instance ID";

    public static final String APP_ID = "Application ID";

    public static final String APP_DISPLAY_NAME = "Application Display Name";

    public static final String APP_VERSION = "Application Version";

    public static final String APP_DESCRIPTION = "Application Description";

    public static final String APP_ELB_ID = "ELB ID";

    public static final String APP_VPC_ID = "VPC ID";

    public static final String APP_CLUSTER_ID = "Cluster ID";

    public static final String APP_TYPE_OPTION = "Application Type";

    public static final String APP_SIZE_OPTION = "Application Size";

    public static final String APP_REPLICAS = "Application Max Scale Size";

    public static final String APP_PORT = "Application Port";

    public static final String SOURCE_TYPE_OPTION = "Source Type";

    public static final String SOURCE_TYPE_LOCAL_FILE = "BIN";

    public static final String SOURCE_TYPE_DEVCLOUD = "DevCloud";

    public static final String SOURCE_TYPE_GITHUB = "GitHub";

    public static final String SOURCE_TYPE_GITEE = "Gitee";

    public static final String SOURCE_TYPE_BITBUCKET = "Bitbucket";

    public static final String SOURCE_TYPE_GITLAB = "Gitlab";

    public static final String SOURCE_PATH = "Path";

    public static final String SOURCE_NAMESPACE = "Namespace";

    public static final String SOURCE_BRANCH = "Branch";

    public static final String SOURCE_SECU_TOKEN = "SECU Token";

    public static final String SWR_REPO = "SWR Repo";

    public static final String SWR_PACKAGE = "SWR Package";

    public static final String SWR_VERSION = "SWR Version";

    public static final String DIALOG_SETTINGS_FILE_NAME = "servicestage.xml";

    public static final String RDB_DESCRIPTION = "RDB Description";

    public static final String RDB_ID = "RDB ID";

    public static final String RDB_CONNECTION_TYPE = "RDB Connection Type";

    public static final String RDB_DB_NAME = "RDB DB Name";

    public static final String RDB_USER = "RDB User";

    public static final String RDB_PASSWORD = "RDB Password";

    public static final String DCS_DESCRIPTION = "DCS Description";

    public static final String DCS_ID = "DCS ID";

    public static final String DCS_CLUSTER = "DCS Cluster";

    public static final String DCS_PASSWORD = "DCS Password";

    public static final String DCS_VERSION = "DCS Version";

    public static final String DCS_TYPE = "DCS Type";
}

/**
 * Copyright 2016 - 2017 Huawei Technologies Co., Ltd. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.huawei.cloud.servicestage.eclipse;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;

import org.eclipse.equinox.security.storage.StorageException;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;

/**
 * @author Farhan Arshad (farhan.arshad@huawei.com)
 */
public class AppConfigWizardPage extends AbstractConfigWizardPage
        implements Resources {

    public AppConfigWizardPage() {
        super(WIZARD_APP_PAGE_PAGE_NAME);
        setTitle(WIZARD_APP_PAGE_TITLE);
        setDescription(WIZARD_APP_PAGE_DESCRIPTION);
    }

    @Override
    public void createControl(Composite parent) {
        // outer container
        Composite container = createContainer(parent);

        // service instance group
        Group serviceInstanceGroup = createGroup(container,
                WIZARD_APP_PAGE_SERVICE_INSTANCE_GROUP_NAME);

        addField(ConfigConstants.SERVICE_INSTANCE_ID,
                WIZARD_APP_PAGE_SERVICE_INSTANCE_ID,
                UUID.randomUUID().toString(), false, serviceInstanceGroup);

        // application group
        Group appGroup = createGroup(container,
                WIZARD_APP_PAGE_APPLICATION_GROUP_NAME);

        addField(ConfigConstants.APP_ID, WIZARD_APP_PAGE_APP_ID, appGroup);
        addField(ConfigConstants.APP_DISPLAY_NAME,
                WIZARD_APP_PAGE_APP_DISPLAY_NAME, appGroup);
        addField(ConfigConstants.APP_VERSION, WIZARD_APP_PAGE_APP_VERSION,
                appGroup);
        addField(ConfigConstants.APP_DESCRIPTION,
                WIZARD_APP_PAGE_APP_DESCRIPTION, appGroup);

        Map<String, String> types = Collections.emptyMap();
        try {
            types = RequestManager.getInstance().getApplicationTypes();
        } catch (IOException | StorageException e) {
            Logger.exception(e);
            this.setErrorMessage(WIZARD_APP_PAGE_APP_TYPE_ERROR);
        }
        addDropdown(ConfigConstants.APP_TYPE_OPTION, WIZARD_APP_PAGE_APP_TYPE,
                types, appGroup);

        addSpinner(ConfigConstants.APP_PORT, WIZARD_APP_PAGE_PORT, 8080, 1,
                99999, appGroup);

        // platform group
        Group platformGroup = createGroup(container,
                WIZARD_APP_PAGE_PLATFORM_GROUP_NAME);

        addField(ConfigConstants.APP_CLUSTER_ID, WIZARD_APP_PAGE_APP_CLUSTER_ID,
                platformGroup);
        addField(ConfigConstants.APP_ELB_ID, WIZARD_APP_PAGE_APP_ELB_ID,
                platformGroup);
        addField(ConfigConstants.APP_VPC_ID, WIZARD_APP_PAGE_APP_VPC_ID,
                platformGroup);

        Map<String, String> sizes = Collections.emptyMap();
        try {
            sizes = RequestManager.getInstance().getAppTShirtSizes();
        } catch (IOException | StorageException e) {
            Logger.exception(e);
            this.setErrorMessage(WIZARD_APP_PAGE_APP_SIZE_ERROR);
        }
        addDropdown(ConfigConstants.APP_SIZE_OPTION, WIZARD_APP_PAGE_APP_SIZE,
                sizes, platformGroup);

        addSpinner(ConfigConstants.APP_REPLICAS, WIZARD_APP_PAGE_APP_REPLICAS,
                1, 1, 99, platformGroup);
    }

    @Override
    protected int getPageLabelWidth() {
        return 100;
    }

}

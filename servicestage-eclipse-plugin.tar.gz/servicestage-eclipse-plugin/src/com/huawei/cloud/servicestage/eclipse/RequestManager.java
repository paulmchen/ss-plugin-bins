/**
 * Copyright 2016 - 2017 Huawei Technologies Co., Ltd. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.huawei.cloud.servicestage.eclipse;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import javax.inject.Inject;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.equinox.security.storage.ISecurePreferences;
import org.eclipse.equinox.security.storage.SecurePreferencesFactory;
import org.eclipse.equinox.security.storage.StorageException;
import org.eclipse.jface.dialogs.IDialogSettings;
import org.eclipse.jface.preference.IPreferenceStore;

import com.huawei.cloud.servicestage.eclipse.preferences.PreferenceConstants;
import com.huawei.cloud.servicestage.client.AuthClient;
import com.huawei.cloud.servicestage.client.ServiceInstanceRequestBody;
import com.huawei.cloud.servicestage.client.ServiceStageClient;
import com.huawei.cloud.servicestage.client.SimpleResponse;
import com.huawei.cloud.servicestage.client.Token;
import com.huawei.cloud.servicestage.client.UploadClient;

/**
 * This class manages requests made to ServiceStage via the ServiceStage
 * Client.<br>
 * <br>
 * It reads information from the Preferences and DialogSettings and passes it to
 * the requests as needed. <br>
 * <br>
 * It is also responsible for managing the Authentication Token, stored in the
 * plug-in's secure preference store.
 * 
 * @author Farhan Arshad (farhan.arshad@huawei.com)
 */
public class RequestManager {
    @Inject
    Logger logger;

    private static RequestManager instance = null;

    // cached
    private Map<String, String> appTShirtSizes = null;

    // cached
    private Map<String, String> applicationTypes = null;

    protected RequestManager() {
    }

    public static RequestManager getInstance() {
        if (instance == null) {
            instance = new RequestManager();
        }

        return instance;
    }

    /**
     * Creates or updates a ServiceStage application instance.
     * 
     * @param project
     * @return
     * @throws IOException
     * @throws StorageException
     */
    public SimpleResponse createOrUpdateApplication(IProject project)
            throws StorageException, IOException {
        IDialogSettings ds = Util.loadDialogSettings(project);

        String serviceInstanceId = ds.get(ConfigConstants.SERVICE_INSTANCE_ID);
        Token token = getAuthToken();

        if (ServiceStageClient.applicationExists(serviceInstanceId, token)) {
            ServiceInstanceRequestBody requestBody = getUpdateAppRequestBody(ds,
                    token);
            Logger.info(requestBody.toString());
            return ServiceStageClient.updateService(serviceInstanceId,
                    requestBody, token);
        } else {
            ServiceInstanceRequestBody requestBody = getCreateAppRequestBody(ds,
                    token);
            Logger.info(requestBody.toString());
            return ServiceStageClient.createService(serviceInstanceId,
                    requestBody, token);
        }
    }

    /**
     * Responsible for gathering all information required by the request body
     * 
     * @param ds
     * @param token
     * @return
     * @throws StorageException
     */
    private ServiceInstanceRequestBody getUpdateAppRequestBody(
            IDialogSettings ds, Token token) throws StorageException {
        ServiceInstanceRequestBody r = new ServiceInstanceRequestBody();

        IPreferenceStore store = Activator.getDefault().getPreferenceStore();

        r.serviceId = store.getString(PreferenceConstants.SERVICE_ID);

        r.parameters = new ServiceInstanceRequestBody.Parameters();

        r.parameters.displayName = ds.get(ConfigConstants.APP_DISPLAY_NAME);
        r.parameters.desc = ds.get(ConfigConstants.APP_DESCRIPTION);

        r.parameters.version = ds.get(ConfigConstants.APP_VERSION);

        r.parameters.size = new ServiceInstanceRequestBody.Parameters.Size();
        r.parameters.size.id = ds.getArray(ConfigConstants.APP_SIZE_OPTION)[1];
        r.parameters.size.replica = ds.getInt(ConfigConstants.APP_REPLICAS);

        r.parameters.source = new ServiceInstanceRequestBody.Parameters.Source();
        r.parameters.source.type = ds
                .getArray(ConfigConstants.SOURCE_TYPE_OPTION)[1];
        r.parameters.source.repoUrl = ds.get(ConfigConstants.SOURCE_PATH);
        r.parameters.source.secuToken = ds
                .get(ConfigConstants.SOURCE_SECU_TOKEN);
        r.parameters.source.repoNamespace = ds
                .get(ConfigConstants.SOURCE_NAMESPACE);
        r.parameters.source.projBranch = ds.get(ConfigConstants.SOURCE_BRANCH);
        r.parameters.source.artifactNamespace = store
                .getString(PreferenceConstants.ARTIFACT_NAMESPACE);

        return r;
    }

    /**
     * Responsible for gathering all information required by the request body
     * 
     * @param ds
     * @param token
     * @return
     * @throws StorageException
     */
    private ServiceInstanceRequestBody getCreateAppRequestBody(
            IDialogSettings ds, Token token) throws StorageException {
        ServiceInstanceRequestBody r = ServiceInstanceRequestBody
                .newEmptyInstance();

        IPreferenceStore store = Activator.getDefault().getPreferenceStore();

        r.serviceId = store.getString(PreferenceConstants.SERVICE_ID);
        r.planId = store.getString(PreferenceConstants.PLAN_ID);
        r.organizationGuid = store
                .getString(PreferenceConstants.ORGANIZATION_GUID);
        r.spaceGuid = store.getString(PreferenceConstants.SPACE_GUID);
        r.context.orderId = store
                .getString(PreferenceConstants.CONTEXT_ORDER_ID);

        r.parameters.name = ds.get(ConfigConstants.APP_ID);
        r.parameters.region = token.getRegion();
        r.parameters.version = ds.get(ConfigConstants.APP_VERSION);
        r.parameters.type = ds.getArray(ConfigConstants.APP_TYPE_OPTION)[1];
        r.parameters.displayName = ds.get(ConfigConstants.APP_DISPLAY_NAME);
        r.parameters.listenerPort = ds.getInt(ConfigConstants.APP_PORT);
        r.parameters.desc = ds.get(ConfigConstants.APP_DESCRIPTION);
        r.parameters.size.id = ds.getArray(ConfigConstants.APP_SIZE_OPTION)[1];
        r.parameters.size.replica = ds.getInt(ConfigConstants.APP_REPLICAS);
        r.parameters.source.type = ds
                .getArray(ConfigConstants.SOURCE_TYPE_OPTION)[1];
        r.parameters.source.repoUrl = ds.get(ConfigConstants.SOURCE_PATH);
        r.parameters.source.secuToken = ds
                .get(ConfigConstants.SOURCE_SECU_TOKEN);
        r.parameters.source.repoNamespace = ds
                .get(ConfigConstants.SOURCE_NAMESPACE);
        r.parameters.source.projBranch = ds.get(ConfigConstants.SOURCE_BRANCH);
        r.parameters.source.artifactNamespace = store
                .getString(PreferenceConstants.ARTIFACT_NAMESPACE);
        r.parameters.platforms.vpc.id = ds.get(ConfigConstants.APP_VPC_ID);
        r.parameters.platforms.cce.id = ds.get(ConfigConstants.APP_CLUSTER_ID);
        r.parameters.platforms.cce.parameters.namespace = "default";
        r.parameters.platforms.elb.id = ds.get(ConfigConstants.APP_ELB_ID);

        if (ds.get(ConfigConstants.DCS_ID) == null
                || ds.get(ConfigConstants.DCS_ID).isEmpty()) {
            r.parameters.services.distributedSession = null;
        } else {
            r.parameters.services.distributedSession.desc = ds
                    .get(ConfigConstants.DCS_DESCRIPTION);
            r.parameters.services.distributedSession.id = ds
                    .get(ConfigConstants.DCS_ID);
            r.parameters.services.distributedSession.parameters.cluster = ds
                    .get(ConfigConstants.DCS_CLUSTER);
            r.parameters.services.distributedSession.parameters.password = ds
                    .get(ConfigConstants.DCS_PASSWORD);
            r.parameters.services.distributedSession.parameters.version = ds
                    .get(ConfigConstants.DCS_VERSION);
            r.parameters.services.distributedSession.parameters.type = ds
                    .get(ConfigConstants.DCS_TYPE);
        }

        if (ds.get(ConfigConstants.RDB_ID) == null
                || ds.get(ConfigConstants.RDB_ID).isEmpty()) {
            r.parameters.services.relationalDatabase = null;
        } else {
            r.parameters.services.relationalDatabase.desc = ds
                    .get(ConfigConstants.RDB_DESCRIPTION);
            r.parameters.services.relationalDatabase.id = ds
                    .get(ConfigConstants.RDB_ID);
            r.parameters.services.relationalDatabase.parameters.connectionType = ds
                    .get(ConfigConstants.RDB_CONNECTION_TYPE);
            r.parameters.services.relationalDatabase.parameters.dbName = ds
                    .get(ConfigConstants.RDB_DB_NAME);
            r.parameters.services.relationalDatabase.parameters.dbUser = ds
                    .get(ConfigConstants.RDB_USER);
            r.parameters.services.relationalDatabase.parameters.password = ds
                    .get(ConfigConstants.RDB_PASSWORD);
        }

        return r;
    }

    /**
     * Gets an auth token for user. The user's information is obtained from the
     * plug-in preferences.
     * 
     * @return
     * @throws IOException
     * @throws StorageException
     */
    public Token getAuthToken() throws StorageException, IOException {
        IPreferenceStore store = Activator.getDefault().getPreferenceStore();
        boolean secure = store.getBoolean(PreferenceConstants.SECURE);
        return getAuthToken(secure);
    }

    /**
     * Gets an auth token for user. The user's information is obtained from the
     * plug-in preferences. <br>
     * <br>
     * This token will also be saved in the secure preference storage. <br>
     * <br>
     * For secure preference storage to work, a master password must be set in
     * Eclipse. If secure storage is not desired, set secure parameter to false.
     * The token will then be stored in plain-text. <br>
     * <br>
     * Note: set secure to false for JUnit testing since master password will
     * not be set.
     * 
     * @param secure
     *            true if token should be stored securely, false otherwise.
     * @return a valid Auth Token or null
     * @throws StorageException
     * @throws IOException
     */
    public Token getAuthToken(boolean secure)
            throws StorageException, IOException {
        IPreferenceStore store = Activator.getDefault().getPreferenceStore();
        String region = store.getString(PreferenceConstants.REGION_CHOICE);
        String username = store.getString(PreferenceConstants.USERNAME);

        ISecurePreferences node = SecurePreferencesFactory.getDefault()
                .node(Activator.PLUGIN_ID);
        String password = node.get(PreferenceConstants.PASSWORD, "");

        // get existing token, if any
        String tokenStr = node.get(PreferenceConstants.TOKEN, "");

        Token token = null;

        // token found in secure store
        if (tokenStr != null && !tokenStr.isEmpty()) {
            Token t = Token.fromString(tokenStr);

            // check if token is valid and not expired
            if (t.getUsername().equals(username) && t.getRegion().equals(region)
                    && !t.isExpired()) {
                token = t;
            }
        }

        // no valid token found
        if (token == null) {
            Logger.info("No valid token found, getting new token");

            token = AuthClient.getAuthToken(region, username, password);
            node.put(PreferenceConstants.TOKEN, token.toString(), secure);
        }

        return token;
    }

    /**
     * Gets the available App T-Shirt sizes.
     * 
     * @return a map where the keys are size display names, and values are size
     *         ids for the api
     * @throws IOException
     * @throws StorageException
     */
    public Map<String, String> getAppTShirtSizes()
            throws IOException, StorageException {
        if (this.appTShirtSizes == null) {
            this.appTShirtSizes = ServiceStageClient
                    .getAppTShirtSizes(getAuthToken());
        }

        return this.appTShirtSizes;
    }

    /**
     * Gets the available application types (e.g. Tomcat, Node.js).
     * 
     * @return a map where the keys are type display names, and values are type
     *         ids for the api
     * @throws IOException
     * @throws StorageException
     */
    public Map<String, String> getApplicationTypes()
            throws IOException, StorageException {
        if (this.applicationTypes == null) {
            this.applicationTypes = ServiceStageClient
                    .getApplicationTypes(getAuthToken());
        }

        return this.applicationTypes;
    }

    /**
     * Gets a set of repos for the user
     * 
     * @return
     * @throws IOException
     * @throws StorageException
     */
    public Set<String> getRepos() throws IOException, StorageException {
        Token token = getAuthToken();
        String domain = token.getUsername();
        String namespace = "default";
        return UploadClient.getRepos(domain, namespace, token);
    }

    /**
     * Gets a set of packages for the repo
     * 
     * @param repo
     * @return
     * @throws IOException
     * @throws StorageException
     */
    public Set<String> getPackages(String repo)
            throws IOException, StorageException {
        Token token = getAuthToken();
        String domain = token.getUsername();
        String namespace = "default";
        return UploadClient.getPackages(domain, namespace, repo, token);
    }

    /**
     * Gets a set of verions for the package in the repo
     * 
     * @param repo
     * @param packageName
     * @return
     * @throws IOException
     * @throws StorageException
     */
    public Set<String> getVersions(String repo, String packageName)
            throws IOException, StorageException {
        Token token = getAuthToken();
        String domain = token.getUsername();
        String namespace = "default";
        return UploadClient.getVersions(domain, namespace, repo, packageName,
                token);
    }

    /**
     * Uploads the specified file to SWR
     * 
     * @param file
     * @param project
     * @return
     * @throws StorageException
     * @throws IOException
     */
    public String upload(IResource file, IProject project)
            throws StorageException, IOException {
        Token token = getAuthToken();

        String name = file.getName();
        String localAbsoluteFilePath = file.getRawLocation().makeAbsolute()
                .toString();

        String domain = token.getUsername();
        String namespace = "default"; // hard-coded for now

        IDialogSettings ds = Util.loadDialogSettings(project);

        String repo = ds.get(ConfigConstants.SWR_REPO);
        String packageName = ds.get(ConfigConstants.SWR_PACKAGE);
        String version = ds.get(ConfigConstants.SWR_VERSION);

        SimpleResponse uploadResponse = UploadClient.upload(
                localAbsoluteFilePath, domain, namespace, repo, packageName,
                version, name, token);

        if (!uploadResponse.isOk()) {
            throw new IOException(uploadResponse.getMessage());
        }

        String url = UploadClient.getExternalUrl(domain, namespace, repo,
                packageName, version, token);

        if (url == null || url.isEmpty()) {
            throw new IOException("Unabled to find uploaded file");
        }

        return url;
    }

    /**
     * Gets information about the application instance
     * 
     * @param project
     * @return
     * @throws IOException
     * @throws StorageException
     */
    public SimpleResponse getApplicationInfo(IProject project)
            throws IOException, StorageException {
        Token token = getAuthToken();
        IDialogSettings ds = Util.loadDialogSettings(project);

        String instanceId = ds.get(ConfigConstants.SERVICE_INSTANCE_ID);

        return ServiceStageClient.getApplicationInfo(instanceId, token);
    }

    /**
     * Gets the task logs for the application instance
     * 
     * @param project
     * @return
     * @throws IOException
     * @throws StorageException
     */
    public SimpleResponse getApplicationTaskLogs(IProject project)
            throws IOException, StorageException {
        Token token = getAuthToken();
        IDialogSettings ds = Util.loadDialogSettings(project);

        String instanceId = ds.get(ConfigConstants.SERVICE_INSTANCE_ID);

        return ServiceStageClient.getApplicationTaskLogs(instanceId, token);
    }

    /**
     * Gets status of the application
     * 
     * @param project
     * @return {@link AppStatus}
     * @throws IOException
     * @throws StorageException
     */
    public AppStatus getApplicationStatus(IProject project)
            throws IOException, StorageException {
        Token token = getAuthToken();
        IDialogSettings ds = Util.loadDialogSettings(project);

        String instanceId = ds.get(ConfigConstants.SERVICE_INSTANCE_ID);

        String status = ServiceStageClient.getApplicationStatus(instanceId,
                token);

        // if app failed, then get task logs to provide more details about
        // failure
        // if app did not fail, then display info about the app instead
        if (status.equals(AppStatus.FAILED)) {
            SimpleResponse taskLogsResponse = getApplicationTaskLogs(project);
            if (taskLogsResponse.isOk()) {
                return new AppStatus(status, taskLogsResponse.getMessage());
            }
        } else {
            SimpleResponse appInfoResponse = getApplicationInfo(project);
            if (appInfoResponse.isOk()) {
                return new AppStatus(status, appInfoResponse.getMessage());
            }
        }

        return new AppStatus(status, "");
    }

    /**
     * Gets the url for the application
     * 
     * @param project
     * @return
     * @throws IOException
     * @throws StorageException
     */
    public String getApplicationUrl(IProject project)
            throws IOException, StorageException {
        Token token = getAuthToken();
        IDialogSettings ds = Util.loadDialogSettings(project);

        String instanceId = ds.get(ConfigConstants.SERVICE_INSTANCE_ID);

        return ServiceStageClient.getApplicationUrl(instanceId, token);
    }
}

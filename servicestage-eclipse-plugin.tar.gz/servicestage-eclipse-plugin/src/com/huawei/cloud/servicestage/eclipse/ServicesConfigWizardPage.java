/**
 * Copyright 2016 - 2017 Huawei Technologies Co., Ltd. All rights reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.huawei.cloud.servicestage.eclipse;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;

/**
 * @author Farhan Arshad (farhan.arshad@huawei.com)
 */
public class ServicesConfigWizardPage extends AbstractConfigWizardPage
        implements Resources {

    protected ServicesConfigWizardPage() {
        super(WIZARD_SERVICES_PAGE_PAGE_NAME);
        setTitle(WIZARD_SERVICES_PAGE_TITLE);
        setDescription(WIZARD_SERVICES_PAGE_DESCRIPTION);
    }

    @Override
    public void createControl(Composite parent) {
        // outer container
        Composite container = createContainer(parent);

        // distributed caching service group
        Group dcsGroup = createGroup(container,
                WIZARD_SERVICES_PAGE_DCS_GROUP_NAME);
        addField(ConfigConstants.DCS_ID, WIZARD_SERVICES_PAGE_DCS_ID, dcsGroup);
        addField(ConfigConstants.DCS_DESCRIPTION,
                WIZARD_SERVICES_PAGE_DCS_DESCRIPTION, dcsGroup);
        addField(ConfigConstants.DCS_CLUSTER, WIZARD_SERVICES_PAGE_DCS_CLUSTER,
                dcsGroup);
        addPasswordField(ConfigConstants.DCS_PASSWORD,
                WIZARD_SERVICES_PAGE_DCS_PASSWORD, dcsGroup);
        addField(ConfigConstants.DCS_VERSION, WIZARD_SERVICES_PAGE_DCS_VERSION,
                dcsGroup);
        addField(ConfigConstants.DCS_TYPE, WIZARD_SERVICES_PAGE_DCS_TYPE,
                dcsGroup);

        // relational database group
        Group rdbGroup = createGroup(container,
                WIZARD_SERVICES_PAGE_RDS_GROUP_NAME);
        addField(ConfigConstants.RDB_ID, WIZARD_SERVICES_PAGE_RDS_ID, rdbGroup);
        addField(ConfigConstants.RDB_DESCRIPTION,
                WIZARD_SERVICES_PAGE_RDS_DESCRIPTION, rdbGroup);
        addField(ConfigConstants.RDB_CONNECTION_TYPE,
                WIZARD_SERVICES_PAGE_RDS_CONNECTION_TYPE, rdbGroup);
        addField(ConfigConstants.RDB_DB_NAME, WIZARD_SERVICES_PAGE_RDS_DB_NAME,
                rdbGroup);
        addField(ConfigConstants.RDB_USER, WIZARD_SERVICES_PAGE_RDS_DB_USER,
                rdbGroup);
        addPasswordField(ConfigConstants.RDB_PASSWORD,
                WIZARD_SERVICES_PAGE_RDS_DB_PASSWORD, rdbGroup);
    }

    @Override
    protected int getPageLabelWidth() {
        return 125;
    }
}
